/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JTable;

/**
 *
 * @author cathl
 */
public class TabMoyenne extends JFrame {

    public TabMoyenne(String jLabel2, String jLabel3) {
        Object[][] donnees = {
            {"Trimestre1", "", "", "", "", ""},
            {"Trimestre2", "", "", "", "", ""},
            {"Trimestre3", "", "", "", "", ""},};

        String[] entetes = {"TRIMESTRE", "Mathematique ", "Français", "Physique", "Anglais", "MOYENNE"};
        float tableaux[] = new float[12];

        //Etablir la moyenne pour la matiere Mathematique par tri
        for (int j = 0; j < 3; j++) {

            resultat2 res1 = new resultat2();
            int tab[] = res1.resultat2(jLabel2, jLabel3, 1, j + 1);
            float moyinfT1 = 0;
            float s = 0;
            float y = 0;
            System.out.println(tab[0]);

            for (int i = 0; i < tab.length; i++) {

                if (tab[i] != 21) {
                    s += tab[i];
                    y += 1;
                }

            }

            moyinfT1 = (float) (s / y);
            s = 0;
            donnees[j][1] = moyinfT1;
            tableaux[j] = moyinfT1;
        }

        //moyennee Francais
        for (int j = 0; j < 3; j++) {
            //Etablir la moyenne pour la matiere informatique par tri
            resultat2 res1 = new resultat2();
            int tab[] = res1.resultat2(jLabel2, jLabel3, 2, j + 1);
            float moyinfT1 = 0;
            float y = 0;
            float s = 0;
            for (int i = 0; i < tab.length; i++) {
                if (tab[i] != 21) {
                    s += tab[i];
                    y += 1;
                }
            }
            moyinfT1 = (float) (s / tab.length);
            donnees[j][2] = moyinfT1;
            tableaux[j + 3] = moyinfT1;
        }

        // MOYENNE Physique
        for (int j = 0; j < 3; j++) {
            //Etablir la moyenne pour la matiere informatique par tri
            resultat2 res1 = new resultat2();
            int tab[] = res1.resultat2(jLabel2, jLabel3, 3, j + 1);
            float moyinfT1 = 0;
            float s = 0;
            float y = 0;
            for (int i = 0; i < tab.length; i++) {
                if (tab[i] != 21) {
                    s += tab[i];
                    y += 1;
                }
            }
            moyinfT1 = (float) (s / tab.length);
            donnees[j][3] = moyinfT1;
            tableaux[j + 6] = moyinfT1;
        }

        // MOYENNE ANGLAIS
        for (int j = 0; j < 3; j++) {
            //Etablir la moyenne pour la matiere informatique par tri
            resultat2 res1 = new resultat2();
            int tab[] = res1.resultat2(jLabel2, jLabel3, 4, j + 1);
            float moyinfT1 = 0;
            float s = 0;
            float y = 0;
            for (int i = 0; i < tab.length; i++) {
                if (tab[i] != 21) {
                    s += tab[i];
                    y += 1;
                }
            }
            moyinfT1 = (float) (s / tab.length);
            donnees[j][3] = moyinfT1;
            tableaux[j + 9] = moyinfT1;
        }
        //attribution de la moyenne
        //MATH
        
       donnees[0][5] =(float) ((tableaux[0] + tableaux[3] +tableaux[6]+tableaux[9])/4);
       donnees[1][5] =(float) ((tableaux[1] + tableaux[4] +tableaux[7]+tableaux[10])/4);
       donnees[2][5] =(float) ((tableaux[2] + tableaux[5] +tableaux[8]+tableaux[11])/4);

        JTable tableau = new JTable(donnees, entetes);

        getContentPane().add(tableau.getTableHeader(), BorderLayout.NORTH);
        getContentPane().add(tableau, BorderLayout.CENTER);

        pack();
    }

}
