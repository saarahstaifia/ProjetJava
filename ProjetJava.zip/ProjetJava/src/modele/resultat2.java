/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import static modele.connecter.connecter;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JTable;
import static sun.security.jgss.GSSUtil.login;



/**
 *
 * @author cathl
 */
public class resultat2 extends JFrame{
     String nomm;
     String prenomm;
     
     public int[] resultat2(String jLabel2, String jLabel3,int ide,int tri){
          int  tab[] = new int[100];
          for (int p=0; p<100;p++){
              tab[p]=21;
          }
             
         
         try { 
             
             int id = ide;
             int triee = tri;
             nomm =jLabel2;
             prenomm = jLabel3;
             String sqll = "SELECT note FROM evaluation WHERE id_DetailBulletin = (SELECT id_DetailBulletin FROM detailbulletin WHERE id_Enseignement = (SELECT id_Enseignement FROM enseignement WHERE id_Discipline = '" + id + "')) AND id_DetailBulletin = (SELECT id_DetailBulletin FROM detailbulletin WHERE id_Inscription = (SELECT id_Inscription FROM inscription WHERE id_Personne = (SELECT id_Personne FROM personne WHERE  nom ="+"'"+nomm+"'" +"AND prenom="+"'"+prenomm+"')))";
            String sql2 = "SELECT note FROM evaluation WHERE id_DetailBulletin = (SELECT id_DetailBulletin FROM detailbulletin WHERE id_Enseignement = (SELECT id_Enseignement FROM enseignement WHERE id_Discipline = '" + id + "') AND id_Bulletin = (SELECT id_Bulletin FROM bulletin WHERE id_Trimestre =(SELECT id_Trimestre FROM trimestre WHERE numero ='" + triee + "') AND id_Inscription = (SELECT id_Inscription FROM inscription WHERE id_Personne=(SELECT id_Personne FROM personne WHERE nom ="+"'"+nomm+"'"+"AND prenom="+"'"+prenomm+"' )) ))";
      
            String sql = "SELECT note FROM evaluation WHERE id_DetailBulletin= (SELECT id_DetailBulletin FROM detailbulletin WHERE id_Enseignement = (SELECT id_Enseignement FROM enseignement WHERE id_Discipline = '"+id+"'))";
            //On se connecte
            Connection conn = connecter();
            PreparedStatement state = conn.prepareStatement(sql2);
      
            ResultSet res = state.executeQuery(sql);
            ResultSetMetaData resultMeta = res.getMetaData();
            //recuperation des notes de l eleve pour la matiere ***
            
          
            while (res.next()){
                int g = 0;
                for(int j = 1; j <= resultMeta.getColumnCount(); j++){
                    
                    
                    g+=1;
                }
                 int[] tabl= new int[g];
                for(int j = 1; j <= resultMeta.getColumnCount(); j++){
                    String nombre = res.getObject(j).toString();
                    
                    int x = Integer.parseInt(nombre);
                    tab[j-1] = x;
                    
                    System.out.println(tab[j-1]);
                    
                }
            }
            
            
      res.close();
      state.close();

    } catch (SQLException e) {
      e.printStackTrace();
    }
         return tab;
       
     }
       
}
