/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.util.Rotation;


/**
 *
 * @author cathl
 */
public class Statistiques extends JFrame {
    
     private static final long serialVersionUID = 1L;
 
    public Statistiques(String applicationTitle, String chartTitle) {
        super(applicationTitle);
        //Creer le dataset contenant les données
        PieDataset dataset = createDataset();
        //Creer le composant graphique
        JFreeChart chart = createChart(dataset, chartTitle);
        //Attacher le graph au panel
        ChartPanel chartPanel = new ChartPanel(chart);
        //Fixer la taille par défaut
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        //Ajouter le panel au JFrame
        setContentPane(chartPanel);
    }
    
    private PieDataset createDataset() {
        DefaultPieDataset result = new DefaultPieDataset();
        result.setValue("Linux", 33);
        result.setValue("Mac", 15);
        result.setValue("Windows", 49);
        return result;
    }
    
    private JFreeChart createChart(PieDataset dataset, String title) {
        JFreeChart chart = ChartFactory.createPieChart3D(title, // chart title
                dataset, // data
                true, // include legend
                true,
                false);
        PiePlot3D plot = (PiePlot3D) chart.getPlot();
        plot.setStartAngle(290);
        plot.setDirection(Rotation.CLOCKWISE);
        plot.setForegroundAlpha(0.5f);
        return chart;
    }
    
    
    
}
