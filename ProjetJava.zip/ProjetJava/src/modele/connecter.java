/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author cha
 */
public class connecter {
    //Se connecter à la base de données
    public static Connection connecter()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url ="jdbc:mysql://localhost:3306/projetjava";
            String user="root";
            String password="";
            Connection cnx = DriverManager.getConnection(url,user,password);
            return cnx;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
