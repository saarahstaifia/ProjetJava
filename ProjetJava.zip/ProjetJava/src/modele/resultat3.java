/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import static modele.connecter.connecter;

/**
 *
 * @author cathl
 */
public class resultat3 {
    
    public String resultat3(){
        try{
              //On se connecte
                 String sql= "SELECT COUNT(id_Personne) FROM personne WHERE   id_Personne = (SELECT id_Personne FROM inscription WHERE id_Inscription = (SELECT id_Inscription FROM bulletin WHERE id_Trimestre = '" + 1 + "' AND id_Bulletin=(SELECT id_Bulletin FROM detailbulletin WHERE  id_Enseignement = (SELECT id_Enseignement FROM enseignement WHERE id_Discipline = '" + 1 + "') AND  id_DetailBulletin = (SELECT id_DetailBulletin FROM evaluation where note < '" + 11+ "')))  )";
                String sql1= "SELECT COUNT(id_Personne) FROM personne WHERE   id_Personne = (SELECT id_Personne FROM inscription WHERE id_Inscription = (SELECT id_Inscription FROM bulletin WHERE id_Trimestre = '" + 1 + "' AND id_Bulletin=(SELECT id_Bulletin FROM detailbulletin WHERE  id_Enseignement = (SELECT id_Enseignement FROM enseignement WHERE id_Discipline = '" + 1 + "') AND  id_DetailBulletin = (SELECT id_DetailBulletin FROM evaluation where note < '" + 11+ "')))  )";
                
                 Connection conn = connecter();
                PreparedStatement state = conn.prepareStatement(sql);
      
                ResultSet res = state.executeQuery(sql);
                ResultSetMetaData resultMeta = res.getMetaData();
                while(res.next()){
                    System.out.println(res.getInt(sql));
                }
                
        }catch(SQLException e){
            e.printStackTrace();
            
        }
        String y = "t";
        return y;
    
}
    
}
