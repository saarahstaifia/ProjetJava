/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static modele.connecter.connecter;

/**
 *
 * @author cha
 */
public class resultat1 {
    public void resultat1(String query) throws SQLException{
      Connection conn = connecter();
      PreparedStatement state;
    try{  
    state = conn.prepareStatement(query);
    state.executeUpdate(query);
    
    }
    catch(SQLException e){
        Logger.getLogger(resultat1.class.getName()).log(Level.SEVERE, null,e);
        
    }
        
    
}

    public void Resultat(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
