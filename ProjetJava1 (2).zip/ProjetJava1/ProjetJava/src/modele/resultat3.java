/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import static modele.connecter.connecter;

/**
 *
 * @author cathl
 */
public class resultat3 {
    
 public String [][] resultat3(){ 
        String tableaue [][] = new String[100][2];
        try{
               

                //On se connecte
                 String sql= "SELECT COUNT(id_Personne) FROM personne WHERE   id_Personne = (SELECT id_Personne FROM inscription WHERE id_Inscription = (SELECT id_Inscription FROM bulletin WHERE id_Trimestre = '" + 1 + "' AND id_Bulletin=(SELECT id_Bulletin FROM detailbulletin WHERE  id_Enseignement = (SELECT id_Enseignement FROM enseignement WHERE id_Discipline = '" + 1 + "') AND  id_DetailBulletin = (SELECT id_DetailBulletin FROM evaluation where note < '" + 11+ "')))  )";
                String sql1= "SELECT COUNT(id_Personne) FROM personne WHERE   id_Personne = (SELECT id_Personne FROM inscription WHERE id_Inscription = (SELECT id_Inscription FROM bulletin WHERE id_Trimestre = '" + 1 + "' AND id_Bulletin=(SELECT id_Bulletin FROM detailbulletin WHERE  id_Enseignement = (SELECT id_Enseignement FROM enseignement WHERE id_Discipline = '" + 1 + "') AND  id_DetailBulletin = (SELECT id_DetailBulletin FROM evaluation where note < '" + 11+ "')))  )";
                String sql2 = "Select nom  FROM personne WHERE type = '" + 1 + "'";
                String sql3 = "Select prenom  FROM personne WHERE type = '" + 1 + "'";
                Connection conn = connecter();
                PreparedStatement state = conn.prepareStatement(sql);
      
                
                ResultSet res = state.executeQuery(sql2);
                ResultSetMetaData resultMeta = res.getMetaData();
                
               
              
                while(res.next()){
                    for(int j = 1; j <= resultMeta.getColumnCount(); j++){
                       
                        tableaue[j][1] = res.getObject(j).toString();
                        System.out.println(tableaue[j][1]);
                    }
                    
                }
                     
                res.close();
                state.close();
                
                Connection conn3 = connecter();
                PreparedStatement state1 = conn3.prepareStatement(sql3);
                ResultSet reso = state1.executeQuery(sql3);
                ResultSetMetaData resultMeta2 = reso.getMetaData();
                
                while(reso.next()){
                    for(int j = 1; j <= resultMeta2.getColumnCount(); j++){
                        
                        tableaue[j][0] = reso.getObject(j).toString();
                        System.out.println(tableaue[j][0]);
                    }
                    
                }
                reso.close();
                state1.close();
                
        }catch(SQLException e){
            e.printStackTrace();
            
        }
        String y = "t";
        return tableaue;
        
   
}  
}
