/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.util.Rotation;


/**
 *
 * @author cathl
 */
public class Statistiques extends JFrame {
    
     private static final long serialVersionUID = 1L;
 
    public Statistiques(String applicationTitle, String chartTitle,String [][] tab, float nombre,float nombre2,float nombre3) {
        super(applicationTitle);
        //Creer le dataset contenant les données
        PieDataset dataset = createDataset(tab,nombre,nombre2,nombre3);
        //Creer le composant graphique
        JFreeChart chart = createChart(dataset, chartTitle);
        //Attacher le graph au panel
        ChartPanel chartPanel = new ChartPanel(chart);
        //Fixer la taille par défaut
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        //Ajouter le panel au JFrame
        setContentPane(chartPanel);
    }

    
    //statistique pour la matiere mathemaque au premier semestre
    public int[] creationmoyenneinf(String [][] tab, float nombre){
        int taille = tab.length;
        int tail = tab[0].length;
        int tablea[]= new int[taille];
        int u  = 0;
        int tabl [] = new int[2];
         resultat2 tabz = new resultat2();
         int tr[] = new int[100];
        for(int j=0; j<taille;j++ ){
           

        //Etablir la moyenne pour la matiere Mathematique par tri
        float  Moyennepri =0;
        for (int i = 0; i < 3; i++) {

            
            tr = tabz.resultat2(tab[j][0], tab[j][1],1,i+1);
            
            float moyinfT1 = 0;
            float s = 0;
            float y = 0;
            

            for (int m = 0; m < tab.length; m++) {

                if (tr[m] != 21) {
                    s += tr[m];
                    y += 1;
                }

            }

            moyinfT1 = (float) (s / y);
            s = 0;
            Moyennepri += moyinfT1;
            
           
            
        }
        if((float)(Moyennepri/3)<nombre){
             tablea[j] = 1;
             u+= 1;
                
        }
           
              
            
            
        }
        tabl[0] = u;
        tabl[1] = (int)(tab.length);
        
        
        return tabl;
                
    }
    
    public int[] creationmoyennesup(String [][] tab, float nombre){
        int taille = tab.length;
        int tail = tab[0].length;
        int tablea[]= new int[taille];
        int u  = 0;
        int tabl [] = new int[2];
         resultat2 tabz = new resultat2();
         int tr[] = new int[100];
        for(int j=0; j<taille;j++ ){
           

        //Etablir la moyenne pour la matiere Mathematique par tri
        float  Moyennepri =0;
        for (int i = 0; i < 3; i++) {

            
            tr = tabz.resultat2(tab[j][0], tab[j][1],1,i+1);
            
            float moyinfT1 = 0;
            float s = 0;
            float y = 0;
            

            for (int m = 0; m < tab.length; m++) {

                if (tr[m] != 21) {
                    s += tr[m];
                    y += 1;
                }

            }

            moyinfT1 = (float) (s / y);
            s = 0;
            Moyennepri += moyinfT1;
            
           
            
        }
        if((float)(Moyennepri/3)>nombre){
             tablea[j] = 1;
             u+= 1;
                
        }
           
              
            
            
        }
        tabl[0] = u;
        tabl[1] = (int)(tab.length);
        
        
        return tabl;
                
    }
    
    public int[] creationmoyennecomp(String [][] tab, float nombre,float nombre2){
        int taille = tab.length;
        int tail = tab[0].length;
        int tablea[]= new int[taille];
        int u  = 0;
        int tabl [] = new int[2];
         resultat2 tabz = new resultat2();
         int tr[] = new int[100];
        for(int j=0; j<taille;j++ ){
           

        //Etablir la moyenne pour la matiere Mathematique par tri
        float  Moyennepri =0;
        for (int i = 0; i < 3; i++) {

            
            tr = tabz.resultat2(tab[j][0], tab[j][1],1,i+1);
            
            float moyinfT1 = 0;
            float s = 0;
            float y = 0;
            

            for (int m = 0; m < tab.length; m++) {

                if (tr[m] != 21) {
                    s += tr[m];
                    y += 1;
                }

            }

            moyinfT1 = (float) (s / y);
            s = 0;
            Moyennepri += moyinfT1;
            
           
            
        }
        if((float)(Moyennepri/3)>nombre &&(float)(Moyennepri/3)<nombre2 ){
             tablea[j] = 1;
             u+= 1;
                
        }
           
              
            
            
        }
        tabl[0] = u;
        tabl[1] = (int)(tab.length);
        
        
        return tabl;
                
    }
    
    
    
    
    private PieDataset createDataset(String [][] tab, float nombre,float nombre2,float nombre3) {
        int tab1[]= creationmoyenneinf(tab,nombre);
        int tab2[]= creationmoyennecomp(tab,nombre,nombre2);
        int tab3[]= creationmoyennecomp(tab,nombre2,nombre3);
        
        float prem = (float)(tab1[0]/tab.length);
        float sec = (float)(tab2[0]/tab.length);
        float troi = (float)(tab3[0]/tab.length);
        
        DefaultPieDataset result = new DefaultPieDataset();
        result.setValue("Ayant moins de 10", prem);
        result.setValue("Ayant plus de 10 et moins de 15", sec);
        result.setValue("Ayant plus de 15", troi);
        return result;
    }
    
    private JFreeChart createChart(PieDataset dataset, String title) {
        JFreeChart chart = ChartFactory.createPieChart3D(title, // chart title
                dataset, // data
                true, // include legend
                true,
                false);
        PiePlot3D plot = (PiePlot3D) chart.getPlot();
        plot.setStartAngle(290);
        plot.setDirection(Rotation.CLOCKWISE);
        plot.setForegroundAlpha(0.5f);
        return chart;
    }
    
    
}
