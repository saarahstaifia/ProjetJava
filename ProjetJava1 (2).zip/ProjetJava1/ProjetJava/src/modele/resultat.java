/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
  

import static modele.connecter.connecter;

/**
 *
 * @author cha
 */
//CTRL + SHIFT + O pour générer les imports
public class resultat {
    
    public String resultat(String query){
    try {
      
        //On se connecte
      Connection conn = connecter();
      PreparedStatement state = conn.prepareStatement(query);
      
      ResultSet res = state.executeQuery();
      ResultSetMetaData resultMeta = res.getMetaData();

 
      
      while (res.next()){
        for(int j = 1; j <= resultMeta.getColumnCount(); j++){
            
            return res.getObject(j).toString();
   
      }     
      }

      res.close();
      state.close();

    } catch (SQLException e) {
      e.printStackTrace();
    }
    return "C'est fait";
}
}
